package com.idus.blog.dto;

public class Options {
	
	private int optionNo;
	private int pieceNo;
	private String options;
	
	public int getOptionNo() {
		return optionNo;
	}
	public void setOptionNo(int optionNo) {
		this.optionNo = optionNo;
	}
	public int getPieceNo() {
		return pieceNo;
	}
	public void setPieceNo(int pieceNo) {
		this.pieceNo = pieceNo;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	
}
